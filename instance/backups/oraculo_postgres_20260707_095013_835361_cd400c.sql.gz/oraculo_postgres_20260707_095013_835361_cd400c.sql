--
-- PostgreSQL database dump
--

\restrict ezgAw8pMyY2Rv4sLvzcIzbdNcCB21wE2X5NGbU1NhZF8DLiSUgwBivpZj9I9MGM

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public.idx_sessions_user;
DROP INDEX IF EXISTS public.idx_scans_owner_status;
DROP INDEX IF EXISTS public.idx_chat_hist_user_sess;
DROP INDEX IF EXISTS public.idx_backups_started;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.scans DROP CONSTRAINT IF EXISTS scans_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_sessions DROP CONSTRAINT IF EXISTS chat_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.chat_history DROP CONSTRAINT IF EXISTS chat_history_pkey;
ALTER TABLE IF EXISTS ONLY public.backups DROP CONSTRAINT IF EXISTS backups_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chat_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.backups ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.scans;
DROP TABLE IF EXISTS public.chat_sessions;
DROP SEQUENCE IF EXISTS public.chat_history_id_seq;
DROP TABLE IF EXISTS public.chat_history;
DROP SEQUENCE IF EXISTS public.backups_id_seq;
DROP TABLE IF EXISTS public.backups;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: oraculo
--

CREATE TABLE public.backups (
    id bigint NOT NULL,
    started_at text,
    engine text,
    status text,
    size_bytes integer,
    file_path text,
    message text
);


ALTER TABLE public.backups OWNER TO oraculo;

--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: public; Owner: oraculo
--

CREATE SEQUENCE public.backups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backups_id_seq OWNER TO oraculo;

--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oraculo
--

ALTER SEQUENCE public.backups_id_seq OWNED BY public.backups.id;


--
-- Name: chat_history; Type: TABLE; Schema: public; Owner: oraculo
--

CREATE TABLE public.chat_history (
    id bigint NOT NULL,
    username text,
    sender text,
    content text,
    is_html integer DEFAULT 0,
    "timestamp" text,
    session_id text
);


ALTER TABLE public.chat_history OWNER TO oraculo;

--
-- Name: chat_history_id_seq; Type: SEQUENCE; Schema: public; Owner: oraculo
--

CREATE SEQUENCE public.chat_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chat_history_id_seq OWNER TO oraculo;

--
-- Name: chat_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oraculo
--

ALTER SEQUENCE public.chat_history_id_seq OWNED BY public.chat_history.id;


--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: oraculo
--

CREATE TABLE public.chat_sessions (
    id text NOT NULL,
    username text,
    created_at text,
    created_ts real
);


ALTER TABLE public.chat_sessions OWNER TO oraculo;

--
-- Name: scans; Type: TABLE; Schema: public; Owner: oraculo
--

CREATE TABLE public.scans (
    id text NOT NULL,
    target text,
    progress real DEFAULT 0,
    stage text,
    status text,
    result_json text,
    owner text,
    session_id text
);


ALTER TABLE public.scans OWNER TO oraculo;

--
-- Name: users; Type: TABLE; Schema: public; Owner: oraculo
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username text,
    password text,
    profile text,
    grupo_cliente text,
    token_zabbix text,
    zabbix_url text,
    ai_model text
);


ALTER TABLE public.users OWNER TO oraculo;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: oraculo
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO oraculo;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: oraculo
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: backups id; Type: DEFAULT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.backups ALTER COLUMN id SET DEFAULT nextval('public.backups_id_seq'::regclass);


--
-- Name: chat_history id; Type: DEFAULT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.chat_history ALTER COLUMN id SET DEFAULT nextval('public.chat_history_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: oraculo
--

COPY public.backups (id, started_at, engine, status, size_bytes, file_path, message) FROM stdin;
1	06/07/2026 16:51:16	postgres	ok	8582	/opt/oraculo-noc/instance/backups/oraculo_postgres_20260706_165116.sql.gz	Backup PostgreSQL (pg_dump) concluído.
2	07/07/2026 02:00:21	postgres	ok	8660	/opt/oraculo-noc/instance/backups/oraculo_postgres_20260707_020021.sql.gz	Backup PostgreSQL (pg_dump) concluído.
\.


--
-- Data for Name: chat_history; Type: TABLE DATA; Schema: public; Owner: oraculo
--

COPY public.chat_history (id, username, sender, content, is_html, "timestamp", session_id) FROM stdin;
1	asv	user	Gere relatório dos meus servidores, ultimos 30 dias!	0	06/07/2026 15:19	1d53fced-a05b-40c8-9e01-dc248694c1a6
2	asv	bot	📊 **Relatório em processamento!**\nEstou coletando os dados do seu ambiente no Zabbix.\n\n*Assim que terminar, o relatório aparecerá automaticamente aqui no chat.*	0	06/07/2026 15:19	1d53fced-a05b-40c8-9e01-dc248694c1a6
3	asv	bot	<p style='color:#00e5ff; font-weight:bold; font-size:15px; margin-bottom:10px;'>✅ Relatório Concluído</p><a href='/static/Dashboard_Executivo_1783362247.html' download='Dashboard_Executivo_1783362247.html' style='display: inline-block; background-color: #00e5ff; color: #121212; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-family: sans-serif; font-weight: bold; font-size: 13px; border: 1px solid #00b4d8; margin-top: 5px; transition: background-color 0.3s;' onmouseover="this.style.backgroundColor='#00b4d8'" onmouseout="this.style.backgroundColor='#00e5ff'">📥 Baixar Relatório</a>	1	06/07/2026 15:24	1d53fced-a05b-40c8-9e01-dc248694c1a6
4	pollux	user	Como esta minha infraestrutura hoje?	0	06/07/2026 15:28	034d2e82-7de6-4352-a116-748982efdb8b
5	pollux	bot	- Status da Infraestrutura (VDC_POLLUX):\n   - CLIENTE_POLLUX_VM_PLX-AD01: Online, IP: 172.16.25.1\n   - CLIENTE_POLLUX_VM_PLX-AD02: Online, IP: fe80::333b:cbe4:e704:7b05\n   - CLIENTE_POLLUX_VM_PLX-DB: Online, IP: fe80::4bd9:a6c0:e785:1da5\n   - CLIENTE_POLLUX_VM_PLX-RDS: Online, IP: 10.10.10.14\n   - CLIENTE_POLLUX_VM_PLX-SAPIENS: Online, IP: 10.10.10.13\n   - CLIENTE_POLLUX_VM_PLX-LS: Online, IP: 127.0.0.1\n   - CLIENTE_POLLUX_VM_PLX-WIKI: Online, IP: 10.10.10.16\n   - CLIENTE_POLLUX_VM_PLX-LS-MX: Online, IP: 10.10.10.17\n   - CLIENTE_POLLUX_FORTIGATE: Monitoramento via API, Online\n\n- Incidentes Detectados (VDC_POLLUX - Últimos 1 dia):\n   - 06/07 14:35: VPN SSL: david.baptista@pollux.com.br conectado (10.212.134.110)\n   - 06/07 14:15: VPN SSL: arno conectado (10.212.134.109)\n   - 06/07 14:09: VPN SSL: viviane.vieira conectado (10.212.134.108)\n   - 06/07 13:37: VPN SSL: ismael.l.morales conectado (10.212.134.106)\n   - 06/07 13:37: VPN SSL: guilherme.de.macedo conectado (10.212.134.105)\n   - 06/07 13:21: VPN SSL: geanini.rodrigues conectado (10.212.134.103)\n   - 06/07 12:59: VPN SSL: valmir.bloedow conectado (10.212.134.100)\n   - 06/07 10:13: VPN SSL: affonso.d.viccari conectado (10.212.134.107)\n   - 06/07 08:23: VPN SSL: daiane.wiemes conectado (10.212.134.104)\n   - 06/07 08:15: VPN SSL: rodrigo.boza conectado (10.212.134.102)\n   - 06/07 08:13: VPN SSL: ricardo.boaventura conectado (10.212.134.101)\n\n- Status de Conexões VPN (Tempo Real):\n   - Nenhum usuário conectado nas VPNs neste momento.	0	06/07/2026 15:29	034d2e82-7de6-4352-a116-748982efdb8b
6	armazem	user	Faça um scan profundo da aplicação https://colegiobonja.com.br/	0	06/07/2026 15:33	e128bfda-50bc-458f-9a3c-9ec3cacb70b9
7	armazem	bot	🛡️ **SecOps Ativado!**\nIniciando scan profundo no alvo: `colegiobonja.com.br`.\n\n*O processo está rodando em background. Assim que o scan terminar, o relatório será gerado automaticamente aqui no chat.*	0	06/07/2026 15:33	e128bfda-50bc-458f-9a3c-9ec3cacb70b9
8	asv	user	Gere novamente relatório dos meus servidores, ultimos 30 dias!	0	06/07/2026 15:53	1d53fced-a05b-40c8-9e01-dc248694c1a6
9	asv	bot	📊 **Relatório em processamento!**\nEstou coletando os dados do seu ambiente no Zabbix.\n\n*Assim que terminar, o relatório aparecerá automaticamente aqui no chat.*	0	06/07/2026 15:53	1d53fced-a05b-40c8-9e01-dc248694c1a6
10	asv	bot	<p style='color:#00e5ff; font-weight:bold; font-size:15px; margin-bottom:10px;'>✅ Relatório Concluído</p><a href='/static/Dashboard_Executivo_1783364402.html' download='Dashboard_Executivo_1783364402.html' style='display: inline-block; background-color: #00e5ff; color: #121212; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-family: sans-serif; font-weight: bold; font-size: 13px; border: 1px solid #00b4d8; margin-top: 5px; transition: background-color 0.3s;' onmouseover="this.style.backgroundColor='#00b4d8'" onmouseout="this.style.backgroundColor='#00e5ff'">📥 Baixar Relatório</a>	1	06/07/2026 16:00	1d53fced-a05b-40c8-9e01-dc248694c1a6
11	armazem	bot	🛡️ **Nmap scan report para colegiobonja.com.br:**\n\n# Relatório Executivo: Avaliação de Segurança do Site colegiobonja.com.br\n\n## 1. Sumário Executivo\nO site colegiobonja.com.br apresenta um risco crítico para a organização. A exposição de diversas vulnerabilidades críticas e de alto impacto pode levar a sérios compromissos de segurança, incluindo a exposição de dados confidenciais e interrupção dos serviços. A continuidade das operações pode ser seriamente afetada, impactando negativamente a reputação e as operações da empresa.\n\n## 2. Superfície de Ataque\n- **Porta 80/TCP**: Serviço HTTP versão 2.0 exposto, representando um risco de ataques de injeção de código e vulnerabilidades de segurança.\n- **Porta 179/TCP**: Serviço tcpwrapped sem versão detectada, o que pode indicar uma configuração insegura ou um serviço desnecessário.\n- **Porta 443/TCP**: Serviço HTTP versão 2.0, com potencial para ataques de injeção SQL e outras vulnerabilidades.\n- **Porta 8443/TCP**: Serviço HTTP versão 2.4.58, expondo diversas vulnerabilidades críticas e de alto impacto.\n\n## 3. Análise de Vulnerabilidades\n- **CVE-2024-38474**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode permitir a execução remota de código. Vetor de exploração: Injeção de código. Impacto: Potencial comprometimento total do servidor.\n- **CVE-2024-38476**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode levar a negação de serviço. Vetor de exploração: Ataque de negação de serviço. Impacto: Interrupção dos serviços.\n- **CVE-2026-28780**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode permitir a execução remota de código. Vetor de exploração: Injeção de código. Impacto: Potencial comprometimento total do servidor.\n- **CVE-2026-29167**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode permitir a execução remota de código. Vetor de exploração: Injeção de código. Impacto: Potencial comprometimento total do servidor.\n- **CVE-2026-44631**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode permitir a execução remota de código. Vetor de exploração: Injeção de código. Impacto: Potencial comprometimento total do servidor.\n- **CVE-2007-6750**: Severidade desconhecida. Vulnerabilidade que pode levar a um ataque de negação de serviço. Vetor de exploração: Ataque Slowloris. Impacto: Interrupção dos serviços web.\n\n## 4. Plano de Remediação Priorizado\n- **Remediar CVE-2024-38474, CVE-2024-38476, CVE-2026-28780, CVE-2026-29167, CVE-2026-44631**: Atualizar o Apache HTTP Server para a versão mais recente e aplicar patches de segurança relevantes. Esforço: Alto. Prazo: Imediato.\n- **Remediar CVE-2007-6750**: Implementar medidas de mitigação contra ataques Slowloris, como limitar o número de conexões simultâneas. Esforço: Médio. Prazo: 30 dias.\n- **Revisar e remover serviços desnecessários**: Avaliar a necessidade do serviço tcpwrapped na porta 179/TCP e removê-lo se não for essencial. Esforço: Baixo. Prazo: Imediato.\n\n## 5. Observações e Limitações\n- Algumas vulnerabilidades foram detectadas sem autenticação, o que pode indicar uma exposição significativa.\n- A detecção de vulnerabilidades pode incluir falsos positivos, especialmente em relação a serviços que não foram autenticados.\n- Recomenda-se uma avaliação mais profunda para confirmar a presença e o impacto real de cada vulnerabilidade.\n\n## 6. Referências (CVEs Identificadas)\n- CVE-2024-38474  —  CVSS 9.8\n- CVE-2024-38476  —  CVSS 9.8\n- CVE-2026-28780  —  CVSS 9.8\n- CVE-2026-29167  —  CVSS 9.8\n- CVE-2026-44631  —  CVSS 9.8\n- CVE-2024-38475  —  CVSS 9.1\n- CVE-2024-40898  —  CVSS 9.1\n- CVE-2025-23048  —  CVSS 9.1\n- CVE-2026-42535  —  CVSS 9.1\n- CVE-2026-24072  —  CVSS 8.8\n- CVE-2025-58098  —  CVSS 8.3\n- CVE-2024-38473  —  CVSS 8.1\n- CVE-2024-27316  —  CVSS 7.5\n- CVE-2024-38472  —  CVSS 7.5\n- CVE-2024-38477  —  CVSS 7.5\n- CVE-2024-39573  —  CVSS 7.5\n- CVE-2024-42516  —  CVSS 7.5\n- CVE-2024-43204  —  CVSS 7.5\n- CVE-2024-43394  —  CVSS 7.5\n- CVE-2024-47252  —  CVSS 7.5\n- CVE-2025-49630  —  CVSS 7.5\n- CVE-2025-53020  —  CVSS 7.5\n- CVE-2025-55753  —  CVSS 7.5\n- CVE-2025-59775  —  CVSS 7.5\n- CVE-2026-29169  —  CVSS 7.5\n- CVE-2026-34059  —  CVSS 7.5\n- CVE-2026-34355  —  CVSS 7.5\n- CVE-2026-34356  —  CVSS 7.5\n- CVE-2026-42536  —  CVSS 7.5\n- CVE-2026-49975  —  CVSS 7.5\n- CVE-2025-49812  —  CVSS 7.4\n- CVE-2023-38709  —  CVSS 7.3\n- CVE-2026-29168  —  CVSS 7.3\n- CVE-2026-44185  —  CVSS 7.3\n- CVE-2026-44186  —  CVSS 7.3\n- CVE-2026-48913  —  CVSS 7.3\n- CVE-2025-65082  —  CVSS 6.5\n- CVE-2026-33523  —  CVSS 6.5\n- CVE-2026-43951  —  CVSS 6.5\n- CVE-2024-24795  —  CVSS 6.3\n- CVE-2026-29170  —  CVSS 6.1\n- CVE-2026-44119  —  CVSS 5.5\n- CVE-2024-36387  —  CVSS 5.4\n- CVE-2025-66200  —  CVSS 5.4\n- CVE-2026-33007  —  CVSS 5.3\n- CVE-2026-33857  —  CVSS 5.3\n- CVE-2026-34032  —  CVSS 5.3\n- CVE-2026-33006  —  CVSS 4.8\n- CVE-2007-6750\n\n[BOTÃO_DOWNLOAD:c8501a57-4ca6-4423-9931-cb0d9b18836e]	0	06/07/2026 16:15	e128bfda-50bc-458f-9a3c-9ec3cacb70b9
12	asv	user	Gere novamente um novo relatório dos meus servidores, ultimos 30 dias!	0	06/07/2026 16:15	1d53fced-a05b-40c8-9e01-dc248694c1a6
13	asv	bot	📊 **Relatório em processamento!**\nEstou coletando os dados do seu ambiente no Zabbix.\n\n*Assim que terminar, o relatório aparecerá automaticamente aqui no chat.*	0	06/07/2026 16:15	1d53fced-a05b-40c8-9e01-dc248694c1a6
14	asv	bot	<p style='color:#00e5ff; font-weight:bold; font-size:15px; margin-bottom:10px;'>✅ Relatório Concluído</p><a href='/static/Dashboard_Executivo_1783365404.html' download='Dashboard_Executivo_1783365404.html' style='display: inline-block; background-color: #00e5ff; color: #121212; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-family: sans-serif; font-weight: bold; font-size: 13px; border: 1px solid #00b4d8; margin-top: 5px; transition: background-color 0.3s;' onmouseover="this.style.backgroundColor='#00b4d8'" onmouseout="this.style.backgroundColor='#00e5ff'">📥 Baixar Relatório</a>	1	06/07/2026 16:16	1d53fced-a05b-40c8-9e01-dc248694c1a6
15	asv	user	Gere novamente um novo relatório dos meus servidores, ultimos 30 dias!	0	06/07/2026 16:21	1d53fced-a05b-40c8-9e01-dc248694c1a6
16	asv	bot	📊 **Relatório em processamento!**\nEstou coletando os dados do seu ambiente no Zabbix.\n\n*Assim que terminar, o relatório aparecerá automaticamente aqui no chat.*	0	06/07/2026 16:21	1d53fced-a05b-40c8-9e01-dc248694c1a6
17	asv	bot	<p style='color:#00e5ff; font-weight:bold; font-size:15px; margin-bottom:10px;'>✅ Relatório Concluído</p><a href='/static/Dashboard_Executivo_1783365769.html' download='Dashboard_Executivo_1783365769.html' style='display: inline-block; background-color: #00e5ff; color: #121212; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-family: sans-serif; font-weight: bold; font-size: 13px; border: 1px solid #00b4d8; margin-top: 5px; transition: background-color 0.3s;' onmouseover="this.style.backgroundColor='#00b4d8'" onmouseout="this.style.backgroundColor='#00e5ff'">📥 Baixar Relatório</a>	1	06/07/2026 16:22	1d53fced-a05b-40c8-9e01-dc248694c1a6
18	admin	user	Como esta minha infraestrutura hoje?	0	07/07/2026 09:43	e72825c4-4f92-47d6-aab0-7b4e7f111afd
19	admin	bot	🚨 **Não consegui conectar ao Zabbix!**\n\nMotivo:\n`ERRO_ZABBIX: Erro de comunicação com o Zabbix: Session terminated, re-login, please.`	0	07/07/2026 09:43	e72825c4-4f92-47d6-aab0-7b4e7f111afd
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: oraculo
--

COPY public.chat_sessions (id, username, created_at, created_ts) FROM stdin;
1d53fced-a05b-40c8-9e01-dc248694c1a6	asv	06/07/2026 15:16	1.7833618e+09
e72825c4-4f92-47d6-aab0-7b4e7f111afd	admin	06/07/2026 15:17	1.7833618e+09
034d2e82-7de6-4352-a116-748982efdb8b	pollux	06/07/2026 15:28	1.7833624e+09
e128bfda-50bc-458f-9a3c-9ec3cacb70b9	armazem	06/07/2026 15:33	1.7833628e+09
\.


--
-- Data for Name: scans; Type: TABLE DATA; Schema: public; Owner: oraculo
--

COPY public.scans (id, target, progress, stage, status, result_json, owner, session_id) FROM stdin;
0b7f5a8b-ff28-4efc-81e2-5f024aa9b772	Relatório FinOps (30 dia(s))	100	Concluído	finished	\N	asv	1d53fced-a05b-40c8-9e01-dc248694c1a6
36ec4997-5145-4b9f-9214-2d6e0a1e59bb	Relatório FinOps (30 dia(s))	100	Concluído	finished	\N	asv	1d53fced-a05b-40c8-9e01-dc248694c1a6
6cea8f5a-87db-4e8a-9587-8d041c3cf582	Relatório FinOps (30 dia(s))	100	Concluído	finished	\N	asv	1d53fced-a05b-40c8-9e01-dc248694c1a6
73257f27-943d-406c-92a7-9d69553cce37	Relatório FinOps (30 dia(s))	100	Concluído	finished	\N	asv	1d53fced-a05b-40c8-9e01-dc248694c1a6
c8501a57-4ca6-4423-9931-cb0d9b18836e	colegiobonja.com.br	100	Concluído	finished	{"scan_data": [{"ip": "177.91.48.11", "ports": [{"id": "80/tcp", "service": "http", "version": "2.0", "vulns": [{"id": "http-stored-xss", "output": "Couldn't find any stored XSS vulnerabilities."}, {"id": "http-title", "output": "Site doesn't have a title (text/html; charset=utf-8)."}, {"id": "http-server-header", "output": "Microsoft-HTTPAPI/2.0"}, {"id": "http-dombased-xss", "output": "Couldn't find any DOM based XSS."}, {"id": "http-csrf", "output": "Couldn't find any CSRF vulnerabilities."}, {"id": "http-enum", "output": "\\n  /robots.txt: Robots file\\n  /manifest.json: Manifest JSON File\\n"}]}, {"id": "179/tcp", "service": "tcpwrapped", "version": null, "vulns": []}, {"id": "443/tcp", "service": "http", "version": "2.0", "vulns": [{"id": "http-title", "output": "Site doesn't have a title (text/html; charset=utf-8)."}, {"id": "http-server-header", "output": "Microsoft-HTTPAPI/2.0"}, {"id": "http-csrf", "output": "Couldn't find any CSRF vulnerabilities."}, {"id": "http-stored-xss", "output": "Couldn't find any stored XSS vulnerabilities."}, {"id": "http-dombased-xss", "output": "Couldn't find any DOM based XSS."}, {"id": "http-sql-injection", "output": "ERROR: Script execution failed (use -d to debug)"}]}, {"id": "8443/tcp", "service": "http", "version": "2.4.58", "vulns": [{"id": "http-server-header", "output": "Apache/2.4.58 (Win64) OpenSSL/3.1.3"}, {"id": "http-stored-xss", "output": "Couldn't find any stored XSS vulnerabilities."}, {"id": "http-dombased-xss", "output": "Couldn't find any DOM based XSS."}, {"id": "http-title", "output": "503 Service Unavailable"}, {"id": "vulners", "output": "\\n  cpe:/a:apache:http_server:2.4.58: \\n    \\tCVE-2026-44631\\t9.8\\thttps://vulners.com/cve/CVE-2026-44631\\n    \\tCVE-2026-29167\\t9.8\\thttps://vulners.com/cve/CVE-2026-29167\\n    \\tCVE-2026-28780\\t9.8\\thttps://vulners.com/cve/CVE-2026-28780\\n    \\tCVE-2024-38476\\t9.8\\thttps://vulners.com/cve/CVE-2024-38476\\n    \\tCVE-2024-38474\\t9.8\\thttps://vulners.com/cve/CVE-2024-38474\\n    \\tCNVD-2024-36391\\t9.8\\thttps://vulners.com/cnvd/CNVD-2024-36391\\n    \\tCNVD-2024-36388\\t9.8\\thttps://vulners.com/cnvd/CNVD-2024-36388\\n    \\tPACKETSTORM:213257\\t9.1\\thttps://vulners.com/packetstorm/PACKETSTORM:213257\\t*EXPLOIT*\\n    \\tFD2EE3A5-BAEA-5845-BA35-E6889992214F\\t9.1\\thttps://vulners.com/githubexploit/FD2EE3A5-BAEA-5845-BA35-E6889992214F\\t*EXPLOIT*\\n    \\tFBC8A8BE-F00A-5B6D-832E-F99A72E7A3F7\\t9.1\\thttps://vulners.com/githubexploit/FBC8A8BE-F00A-5B6D-832E-F99A72E7A3F7\\t*EXPLOIT*\\n    \\tE606D7F4-5FA2-5907-B30E-367D6FFECD89\\t9.1\\thttps://vulners.com/githubexploit/E606D7F4-5FA2-5907-B30E-367D6FFECD89\\t*EXPLOIT*\\n    \\tD8A19443-2A37-5592-8955-F614504AAF45\\t9.1\\thttps://vulners.com/githubexploit/D8A19443-2A37-5592-8955-F614504AAF45\\t*EXPLOIT*\\n    \\tCVE-2026-42535\\t9.1\\thttps://vulners.com/cve/CVE-2026-42535\\n    \\tCVE-2025-23048\\t9.1\\thttps://vulners.com/cve/CVE-2025-23048\\n    \\tCVE-2024-40898\\t9.1\\thttps://vulners.com/cve/CVE-2024-40898\\n    \\tCVE-2024-38475\\t9.1\\thttps://vulners.com/cve/CVE-2024-38475\\n    \\tCNVD-2025-16610\\t9.1\\thttps://vulners.com/cnvd/CNVD-2025-16610\\n    \\tCNVD-2024-36387\\t9.1\\thttps://vulners.com/cnvd/CNVD-2024-36387\\n    \\tCNVD-2024-33814\\t9.1\\thttps://vulners.com/cnvd/CNVD-2024-33814\\n    \\tB5E74010-A082-5ECE-AB37-623A5B33FE7D\\t9.1\\thttps://vulners.com/githubexploit/B5E74010-A082-5ECE-AB37-623A5B33FE7D\\t*EXPLOIT*\\n    \\t5418A85B-F4B7-5BBD-B106-0800AC961C7A\\t9.1\\thttps://vulners.com/githubexploit/5418A85B-F4B7-5BBD-B106-0800AC961C7A\\t*EXPLOIT*\\n    \\tCVE-2026-24072\\t8.8\\thttps://vulners.com/cve/CVE-2026-24072\\n    \\t40379BCA-07F4-5401-B618-4640793D350D\\t8.8\\thttps://vulners.com/githubexploit/40379BCA-07F4-5401-B618-4640793D350D\\t*EXPLOIT*\\n    \\tCVE-2025-58098\\t8.3\\thttps://vulners.com/cve/CVE-2025-58098\\n    \\tB0A9E5E8-7CCC-5984-9922-A89F11D6BF38\\t8.2\\thttps://vulners.com/githubexploit/B0A9E5E8-7CCC-5984-9922-A89F11D6BF38\\t*EXPLOIT*\\n    \\tCVE-2024-38473\\t8.1\\thttps://vulners.com/cve/CVE-2024-38473\\n    \\t23079A70-8B37-56D2-9D37-F638EBF7F8B5\\t8.1\\thttps://vulners.com/githubexploit/23079A70-8B37-56D2-9D37-F638EBF7F8B5\\t*EXPLOIT*\\n    \\tEDEE9204-2DB4-5931-983F-6C7DB7FD4FB7\\t7.5\\thttps://vulners.com/githubexploit/EDEE9204-2DB4-5931-983F-6C7DB7FD4FB7\\t*EXPLOIT*\\n    \\tCVE-2026-49975\\t7.5\\thttps://vulners.com/cve/CVE-2026-49975\\n    \\tCVE-2026-42536\\t7.5\\thttps://vulners.com/cve/CVE-2026-42536\\n    \\tCVE-2026-34356\\t7.5\\thttps://vulners.com/cve/CVE-2026-34356\\n    \\tCVE-2026-34355\\t7.5\\thttps://vulners.com/cve/CVE-2026-34355\\n    \\tCVE-2026-34059\\t7.5\\thttps://vulners.com/cve/CVE-2026-34059\\n    \\tCVE-2026-29169\\t7.5\\thttps://vulners.com/cve/CVE-2026-29169\\n    \\tCVE-2025-59775\\t7.5\\thttps://vulners.com/cve/CVE-2025-59775\\n    \\tCVE-2025-55753\\t7.5\\thttps://vulners.com/cve/CVE-2025-55753\\n    \\tCVE-2025-53020\\t7.5\\thttps://vulners.com/cve/CVE-2025-53020\\n    \\tCVE-2025-49630\\t7.5\\thttps://vulners.com/cve/CVE-2025-49630\\n    \\tCVE-2024-47252\\t7.5\\thttps://vulners.com/cve/CVE-2024-47252\\n    \\tCVE-2024-43394\\t7.5\\thttps://vulners.com/cve/CVE-2024-43394\\n    \\tCVE-2024-43204\\t7.5\\thttps://vulners.com/cve/CVE-2024-43204\\n    \\tCVE-2024-42516\\t7.5\\thttps://vulners.com/cve/CVE-2024-42516\\n    \\tCVE-2024-39573\\t7.5\\thttps://vulners.com/cve/CVE-2024-39573\\n    \\tCVE-2024-38477\\t7.5\\thttps://vulners.com/cve/CVE-2024-38477\\n    \\tCVE-2024-38472\\t7.5\\thttps://vulners.com/cve/CVE-2024-38472\\n    \\tCVE-2024-27316\\t7.5\\thttps://vulners.com/cve/CVE-2024-27316\\n    \\tCNVD-2025-30837\\t7.5\\thttps://vulners.com/cnvd/CNVD-2025-30837\\n    \\tCNVD-2025-30836\\t7.5\\thttps://vulners.com/cnvd/CNVD-2025-30836\\n    \\tCNVD-2025-16614\\t7.5\\thttps://vulners.com/cnvd/CNVD-2025-16614\\n    \\tCNVD-2025-16613\\t7.5\\thttps://vulners.com/cnvd/CNVD-2025-16613\\n    \\tCNVD-2025-16612\\t7.5\\thttps://vulners.com/cnvd/CNVD-2025-16612\\n    \\tCNVD-2025-16609\\t7.5\\thttps://vulners.com/cnvd/CNVD-2025-16609\\n    \\tCNVD-2025-16608\\t7.5\\thttps://vulners.com/cnvd/CNVD-2025-16608\\n    \\tCNVD-2025-16603\\t7.5\\thttps://vulners.com/cnvd/CNVD-2025-16603\\n    \\tCNVD-2024-36393\\t7.5\\thttps://vulners.com/cnvd/CNVD-2024-36393\\n    \\tCNVD-2024-36390\\t7.5\\thttps://vulners.com/cnvd/CNVD-2024-36390\\n    \\tCNVD-2024-36389\\t7.5\\thttps://vulners.com/cnvd/CNVD-2024-36389\\n    \\tCNVD-2024-20839\\t7.5\\thttps://vulners.com/cnvd/CNVD-2024-20839\\n    \\tCDC791CD-A414-5ABE-A897-7CFA3C2D3D29\\t7.5\\thttps://vulners.com/githubexploit/CDC791CD-A414-5ABE-A897-7CFA3C2D3D29\\t*EXPLOIT*\\n    \\tC2EB4AA1-0C70-5104-AF4C-BC274F5A5B7A\\t7.5\\thttps://vulners.com/githubexploit/C2EB4AA1-0C70-5104-AF4C-BC274F5A5B7A\\t*EXPLOIT*\\n    \\tA5675239-3520-5F86-A975-8C0FBB77C2A9\\t7.5\\thttps://vulners.com/githubexploit/A5675239-3520-5F86-A975-8C0FBB77C2A9\\t*EXPLOIT*\\n    \\t742112F7-4755-5E94-8DD2-899160B59E5E\\t7.5\\thttps://vulners.com/githubexploit/742112F7-4755-5E94-8DD2-899160B59E5E\\t*EXPLOIT*\\n    \\t5B7082BE-022C-5DCA-BCDA-0F8EDD0E5085\\t7.5\\thttps://vulners.com/githubexploit/5B7082BE-022C-5DCA-BCDA-0F8EDD0E5085\\t*EXPLOIT*\\n    \\t4B051C78-13E6-52F9-A39E-4C7E49ACB51A\\t7.5\\thttps://vulners.com/githubexploit/4B051C78-13E6-52F9-A39E-4C7E49ACB51A\\t*EXPLOIT*\\n    \\t45D138AD-BEC6-552A-91EA-8816914CA7F4\\t7.5\\thttps://vulners.com/githubexploit/45D138AD-BEC6-552A-91EA-8816914CA7F4\\t*EXPLOIT*\\n    \\t0E08753E-C6D7-5E76-A61F-6CA6F7F87AA8\\t7.5\\thttps://vulners.com/githubexploit/0E08753E-C6D7-5E76-A61F-6CA6F7F87AA8\\t*EXPLOIT*\\n    \\tCVE-2025-49812\\t7.4\\thttps://vulners.com/cve/CVE-2025-49812\\n    \\tCVE-2026-48913\\t7.3\\thttps://vulners.com/cve/CVE-2026-48913\\n    \\tCVE-2026-44186\\t7.3\\thttps://vulners.com/cve/CVE-2026-44186\\n    \\tCVE-2026-44185\\t7.3\\thttps://vulners.com/cve/CVE-2026-44185\\n    \\tCVE-2026-29168\\t7.3\\thttps://vulners.com/cve/CVE-2026-29168\\n    \\tCVE-2023-38709\\t7.3\\thttps://vulners.com/cve/CVE-2023-38709\\n    \\tCNVD-2024-36395\\t7.3\\thttps://vulners.com/cnvd/CNVD-2024-36395\\n    \\tCVE-2026-43951\\t6.5\\thttps://vulners.com/cve/CVE-2026-43951\\n    \\tCVE-2026-33523\\t6.5\\thttps://vulners.com/cve/CVE-2026-33523\\n    \\tCVE-2025-65082\\t6.5\\thttps://vulners.com/cve/CVE-2025-65082\\n    \\tCNVD-2025-30833\\t6.5\\thttps://vulners.com/cnvd/CNVD-2025-30833\\n    \\tCVE-2024-24795\\t6.3\\thttps://vulners.com/cve/CVE-2024-24795\\n    \\tCNVD-2024-36394\\t6.3\\thttps://vulners.com/cnvd/CNVD-2024-36394\\n    \\tCVE-2026-29170\\t6.1\\thttps://vulners.com/cve/CVE-2026-29170\\n    \\tCVE-2026-44119\\t5.5\\thttps://vulners.com/cve/CVE-2026-44119\\n    \\tCVE-2025-66200\\t5.4\\thttps://vulners.com/cve/CVE-2025-66200\\n    \\tCVE-2024-36387\\t5.4\\thttps://vulners.com/cve/CVE-2024-36387\\n    \\tCNVD-2025-30835\\t5.4\\thttps://vulners.com/cnvd/CNVD-2025-30835\\n    \\tCNVD-2024-36392\\t5.4\\thttps://vulners.com/cnvd/CNVD-2024-36392\\n    \\tCVE-2026-34032\\t5.3\\thttps://vulners.com/cve/CVE-2026-34032\\n    \\tCVE-2026-33857\\t5.3\\thttps://vulners.com/cve/CVE-2026-33857\\n    \\tCVE-2026-33007\\t5.3\\thttps://vulners.com/cve/CVE-2026-33007\\n    \\tEA6ADD14-D80B-5DC2-9991-1F9663E2D09F\\t4.8\\thttps://vulners.com/githubexploit/EA6ADD14-D80B-5DC2-9991-1F9663E2D09F\\t*EXPLOIT*\\n    \\tCVE-2026-33006\\t4.8\\thttps://vulners.com/cve/CVE-2026-33006\\n    \\t74A7BA4E-D496-587B-A72A-FA0BE663F994\\t0.0\\thttps://vulners.com/githubexploit/74A7BA4E-D496-587B-A72A-FA0BE663F994\\t*EXPLOIT*"}, {"id": "http-slowloris-check", "output": "\\n  VULNERABLE:\\n  Slowloris DOS attack\\n    State: LIKELY VULNERABLE\\n    IDs:  CVE:CVE-2007-6750\\n      Slowloris tries to keep many connections to the target web server open and hold\\n      them open as long as possible.  It accomplishes this by opening connections to\\n      the target web server and sending a partial request. By doing so, it starves\\n      the http server's resources causing Denial Of Service.\\n      \\n    Disclosure date: 2009-09-17\\n    References:\\n      https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2007-6750\\n      http://ha.ckers.org/slowloris/\\n"}, {"id": "http-csrf", "output": "Couldn't find any CSRF vulnerabilities."}]}]}], "ai_analysis": "# Relat\\u00f3rio Executivo: Avalia\\u00e7\\u00e3o de Seguran\\u00e7a do Site colegiobonja.com.br\\n\\n## 1. Sum\\u00e1rio Executivo\\nO site colegiobonja.com.br apresenta um risco cr\\u00edtico para a organiza\\u00e7\\u00e3o. A exposi\\u00e7\\u00e3o de diversas vulnerabilidades cr\\u00edticas e de alto impacto pode levar a s\\u00e9rios compromissos de seguran\\u00e7a, incluindo a exposi\\u00e7\\u00e3o de dados confidenciais e interrup\\u00e7\\u00e3o dos servi\\u00e7os. A continuidade das opera\\u00e7\\u00f5es pode ser seriamente afetada, impactando negativamente a reputa\\u00e7\\u00e3o e as opera\\u00e7\\u00f5es da empresa.\\n\\n## 2. Superf\\u00edcie de Ataque\\n- **Porta 80/TCP**: Servi\\u00e7o HTTP vers\\u00e3o 2.0 exposto, representando um risco de ataques de inje\\u00e7\\u00e3o de c\\u00f3digo e vulnerabilidades de seguran\\u00e7a.\\n- **Porta 179/TCP**: Servi\\u00e7o tcpwrapped sem vers\\u00e3o detectada, o que pode indicar uma configura\\u00e7\\u00e3o insegura ou um servi\\u00e7o desnecess\\u00e1rio.\\n- **Porta 443/TCP**: Servi\\u00e7o HTTP vers\\u00e3o 2.0, com potencial para ataques de inje\\u00e7\\u00e3o SQL e outras vulnerabilidades.\\n- **Porta 8443/TCP**: Servi\\u00e7o HTTP vers\\u00e3o 2.4.58, expondo diversas vulnerabilidades cr\\u00edticas e de alto impacto.\\n\\n## 3. An\\u00e1lise de Vulnerabilidades\\n- **CVE-2024-38474**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode permitir a execu\\u00e7\\u00e3o remota de c\\u00f3digo. Vetor de explora\\u00e7\\u00e3o: Inje\\u00e7\\u00e3o de c\\u00f3digo. Impacto: Potencial comprometimento total do servidor.\\n- **CVE-2024-38476**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode levar a nega\\u00e7\\u00e3o de servi\\u00e7o. Vetor de explora\\u00e7\\u00e3o: Ataque de nega\\u00e7\\u00e3o de servi\\u00e7o. Impacto: Interrup\\u00e7\\u00e3o dos servi\\u00e7os.\\n- **CVE-2026-28780**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode permitir a execu\\u00e7\\u00e3o remota de c\\u00f3digo. Vetor de explora\\u00e7\\u00e3o: Inje\\u00e7\\u00e3o de c\\u00f3digo. Impacto: Potencial comprometimento total do servidor.\\n- **CVE-2026-29167**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode permitir a execu\\u00e7\\u00e3o remota de c\\u00f3digo. Vetor de explora\\u00e7\\u00e3o: Inje\\u00e7\\u00e3o de c\\u00f3digo. Impacto: Potencial comprometimento total do servidor.\\n- **CVE-2026-44631**: Severidade desconhecida. Vulnerabilidade no Apache HTTP Server que pode permitir a execu\\u00e7\\u00e3o remota de c\\u00f3digo. Vetor de explora\\u00e7\\u00e3o: Inje\\u00e7\\u00e3o de c\\u00f3digo. Impacto: Potencial comprometimento total do servidor.\\n- **CVE-2007-6750**: Severidade desconhecida. Vulnerabilidade que pode levar a um ataque de nega\\u00e7\\u00e3o de servi\\u00e7o. Vetor de explora\\u00e7\\u00e3o: Ataque Slowloris. Impacto: Interrup\\u00e7\\u00e3o dos servi\\u00e7os web.\\n\\n## 4. Plano de Remedia\\u00e7\\u00e3o Priorizado\\n- **Remediar CVE-2024-38474, CVE-2024-38476, CVE-2026-28780, CVE-2026-29167, CVE-2026-44631**: Atualizar o Apache HTTP Server para a vers\\u00e3o mais recente e aplicar patches de seguran\\u00e7a relevantes. Esfor\\u00e7o: Alto. Prazo: Imediato.\\n- **Remediar CVE-2007-6750**: Implementar medidas de mitiga\\u00e7\\u00e3o contra ataques Slowloris, como limitar o n\\u00famero de conex\\u00f5es simult\\u00e2neas. Esfor\\u00e7o: M\\u00e9dio. Prazo: 30 dias.\\n- **Revisar e remover servi\\u00e7os desnecess\\u00e1rios**: Avaliar a necessidade do servi\\u00e7o tcpwrapped na porta 179/TCP e remov\\u00ea-lo se n\\u00e3o for essencial. Esfor\\u00e7o: Baixo. Prazo: Imediato.\\n\\n## 5. Observa\\u00e7\\u00f5es e Limita\\u00e7\\u00f5es\\n- Algumas vulnerabilidades foram detectadas sem autentica\\u00e7\\u00e3o, o que pode indicar uma exposi\\u00e7\\u00e3o significativa.\\n- A detec\\u00e7\\u00e3o de vulnerabilidades pode incluir falsos positivos, especialmente em rela\\u00e7\\u00e3o a servi\\u00e7os que n\\u00e3o foram autenticados.\\n- Recomenda-se uma avalia\\u00e7\\u00e3o mais profunda para confirmar a presen\\u00e7a e o impacto real de cada vulnerabilidade.\\n\\n## 6. Refer\\u00eancias (CVEs Identificadas)\\n- CVE-2024-38474  \\u2014  CVSS 9.8\\n- CVE-2024-38476  \\u2014  CVSS 9.8\\n- CVE-2026-28780  \\u2014  CVSS 9.8\\n- CVE-2026-29167  \\u2014  CVSS 9.8\\n- CVE-2026-44631  \\u2014  CVSS 9.8\\n- CVE-2024-38475  \\u2014  CVSS 9.1\\n- CVE-2024-40898  \\u2014  CVSS 9.1\\n- CVE-2025-23048  \\u2014  CVSS 9.1\\n- CVE-2026-42535  \\u2014  CVSS 9.1\\n- CVE-2026-24072  \\u2014  CVSS 8.8\\n- CVE-2025-58098  \\u2014  CVSS 8.3\\n- CVE-2024-38473  \\u2014  CVSS 8.1\\n- CVE-2024-27316  \\u2014  CVSS 7.5\\n- CVE-2024-38472  \\u2014  CVSS 7.5\\n- CVE-2024-38477  \\u2014  CVSS 7.5\\n- CVE-2024-39573  \\u2014  CVSS 7.5\\n- CVE-2024-42516  \\u2014  CVSS 7.5\\n- CVE-2024-43204  \\u2014  CVSS 7.5\\n- CVE-2024-43394  \\u2014  CVSS 7.5\\n- CVE-2024-47252  \\u2014  CVSS 7.5\\n- CVE-2025-49630  \\u2014  CVSS 7.5\\n- CVE-2025-53020  \\u2014  CVSS 7.5\\n- CVE-2025-55753  \\u2014  CVSS 7.5\\n- CVE-2025-59775  \\u2014  CVSS 7.5\\n- CVE-2026-29169  \\u2014  CVSS 7.5\\n- CVE-2026-34059  \\u2014  CVSS 7.5\\n- CVE-2026-34355  \\u2014  CVSS 7.5\\n- CVE-2026-34356  \\u2014  CVSS 7.5\\n- CVE-2026-42536  \\u2014  CVSS 7.5\\n- CVE-2026-49975  \\u2014  CVSS 7.5\\n- CVE-2025-49812  \\u2014  CVSS 7.4\\n- CVE-2023-38709  \\u2014  CVSS 7.3\\n- CVE-2026-29168  \\u2014  CVSS 7.3\\n- CVE-2026-44185  \\u2014  CVSS 7.3\\n- CVE-2026-44186  \\u2014  CVSS 7.3\\n- CVE-2026-48913  \\u2014  CVSS 7.3\\n- CVE-2025-65082  \\u2014  CVSS 6.5\\n- CVE-2026-33523  \\u2014  CVSS 6.5\\n- CVE-2026-43951  \\u2014  CVSS 6.5\\n- CVE-2024-24795  \\u2014  CVSS 6.3\\n- CVE-2026-29170  \\u2014  CVSS 6.1\\n- CVE-2026-44119  \\u2014  CVSS 5.5\\n- CVE-2024-36387  \\u2014  CVSS 5.4\\n- CVE-2025-66200  \\u2014  CVSS 5.4\\n- CVE-2026-33007  \\u2014  CVSS 5.3\\n- CVE-2026-33857  \\u2014  CVSS 5.3\\n- CVE-2026-34032  \\u2014  CVSS 5.3\\n- CVE-2026-33006  \\u2014  CVSS 4.8\\n- CVE-2007-6750"}	armazem	e128bfda-50bc-458f-9a3c-9ec3cacb70b9
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: oraculo
--

COPY public.users (id, username, password, profile, grupo_cliente, token_zabbix, zabbix_url, ai_model) FROM stdin;
2	asv	scrypt:32768:8:1$U3lXOkSQo70LA6yP$8a1b80d69ba483b069a9f9c0ae576a0931954f5cd59a6756262cad820d658721a1d78b45458f9c175c8a5c6f3aad672c77af37a26cbe4e10be2a78823e527a23	CLIENTE	VDC_ASV	5830aadbac815617fb5acd4c8a92c9286f84604236d495cd8ce48cebcf04bdd4	https://monitoramento.armazem.cloud/api_jsonrpc.php	cohere.command-latest
3	pollux	scrypt:32768:8:1$ejPR2ZGtmKd4SJE5$a8e290fb65e8459e7c34c1a1bfcd2851cf142861b4d4bda0cbc9b22d856e9e0d8bc07be762832a1f873837c59687f77547b77c63c4de22321a689b6c7e2b713d	CLIENTE	VDC_POLLUX	170c54241798b526554c20a6d4ad547dee333e9ddd2a5a7e0f8f33062b409d57	https://monitoramento.armazem.cloud/api_jsonrpc.php	cohere.command-latest
4	armazem	scrypt:32768:8:1$c8Sr9xM4RGLrSR1r$0d14affc4d36b3ef3829cfa69cc76c9fa54ee0969c88835557fecb220912f63ebd8dff6c88115a4cfe4485a0b454fa2430357db672326e4f84664b81d2d10b3d	ADMINISTRADOR	ARMAZEM_CLOUD_INFRAESTRUTURA	ba91235ad31adf6692b7c3bf786d065c758bff908be6796fb58abadc386f45a3	https://monitoramento.armazem.cloud/api_jsonrpc.php	cohere.command-latest
1	admin	scrypt:32768:8:1$qeUSiwp0ah9XTNHm$790871aaf2d4b46d19c90d4a1cb3ee5fac741db722ab1b619ba365478cae234685ce7d9a4e26c91ede196f2d8de60c0f55893eee0e8ac9fff013506d4286149d	ADMINISTRADOR	GLOBAL	None	https://monitoramento.armazem.cloud/api_jsonrpc.php	cohere.command-r-08-2024
\.


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oraculo
--

SELECT pg_catalog.setval('public.backups_id_seq', 2, true);


--
-- Name: chat_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oraculo
--

SELECT pg_catalog.setval('public.chat_history_id_seq', 19, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: oraculo
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: chat_history chat_history_pkey; Type: CONSTRAINT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.chat_history
    ADD CONSTRAINT chat_history_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: scans scans_pkey; Type: CONSTRAINT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.scans
    ADD CONSTRAINT scans_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: oraculo
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_backups_started; Type: INDEX; Schema: public; Owner: oraculo
--

CREATE INDEX idx_backups_started ON public.backups USING btree (started_at);


--
-- Name: idx_chat_hist_user_sess; Type: INDEX; Schema: public; Owner: oraculo
--

CREATE INDEX idx_chat_hist_user_sess ON public.chat_history USING btree (username, session_id);


--
-- Name: idx_scans_owner_status; Type: INDEX; Schema: public; Owner: oraculo
--

CREATE INDEX idx_scans_owner_status ON public.scans USING btree (owner, status);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: oraculo
--

CREATE INDEX idx_sessions_user ON public.chat_sessions USING btree (username, created_ts);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO oraculo;


--
-- PostgreSQL database dump complete
--

\unrestrict ezgAw8pMyY2Rv4sLvzcIzbdNcCB21wE2X5NGbU1NhZF8DLiSUgwBivpZj9I9MGM

